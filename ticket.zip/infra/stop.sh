#!/bin/bash
echo "Bajando infraestructura local..."
docker compose down
echo "Servicios detenidos."
