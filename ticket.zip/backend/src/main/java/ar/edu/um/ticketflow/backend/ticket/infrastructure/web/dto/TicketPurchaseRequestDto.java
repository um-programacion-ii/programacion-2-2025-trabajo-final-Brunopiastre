package ar.edu.um.ticketflow.backend.ticket.infrastructure.web.dto;

public class TicketPurchaseRequestDto {
}
