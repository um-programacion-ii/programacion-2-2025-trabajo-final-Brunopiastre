package ar.edu.um.ticketflow.backend.event.infrastructure.adapter.in.web.dto;

public class EventNotificationDto {
}
