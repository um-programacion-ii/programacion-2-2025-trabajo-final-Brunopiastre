package ar.edu.um.ticketflow.backend.ticket.domain;

public enum TicketStatus {
    CREATED,
    RESERVED,
    SOLD,
    CANCELED
}
