package ar.edu.um.ticketflow.backend.event.infrastructure.adapter.in.web.dto;

import java.time.LocalDateTime;

public class CreateEventRequestDto {

    private String name;
    private String location;
    private LocalDateTime startDate;
    private LocalDateTime endDate;

    public CreateEventRequestDto() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }
}
