package ar.edu.um.ticketflow.backend.auth;

public record LoginResponse(String id_token) {}
