package ar.edu.um.ticketflow.backend.ticket.domain;

public class TicketType {
}
