package ar.edu.um.ticketflow.backend.user.domain;

public enum UserRole {
  ROLE_USER,
  ROLE_ADMIN
}
