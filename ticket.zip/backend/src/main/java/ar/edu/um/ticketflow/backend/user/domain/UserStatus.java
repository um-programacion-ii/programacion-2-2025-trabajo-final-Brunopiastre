package ar.edu.um.ticketflow.backend.user.domain;

public enum UserStatus {
  ACTIVE,
  INACTIVE,
  BANNED
}
