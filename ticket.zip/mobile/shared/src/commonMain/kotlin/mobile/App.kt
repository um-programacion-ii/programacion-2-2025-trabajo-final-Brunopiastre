package mobile

class App {
    fun saludo() = "Hola Bruno desde KMM!"
}
