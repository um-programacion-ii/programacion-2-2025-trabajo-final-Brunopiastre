package mobile.confirmacion

class ConfirmacionService {
    fun confirmar(): String {
        return "Venta confirmada exitosamente"
    }
}
