# E2E - Flujo completo de compra

## Pasos:
1. Mobile hace login.
2. Mobile obtiene lista de eventos.
3. Mobile selecciona evento.
4. Mobile obtiene estado de asientos.
5. Mobile bloquea asientos.
6. Mobile envía información de nombres.
7. Mobile realiza la compra.
8. Backend guarda venta.
9. Proxy notifica cambios.
10. Mobile recibe confirmación.

Resultado esperado: VENDE correctamente.
